# GuessThePrez
A Guessing Game where the program attempts to deduce which President of the United States the user is thinking of
